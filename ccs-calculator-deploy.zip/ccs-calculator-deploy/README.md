# CCS Calculator — It's So Jo

Free Child Care Subsidy calculator for Australian families. 2025–26 rates, includes the January 2026 Three Day Guarantee.

Built by [@itssojo_](https://www.instagram.com/itssojo_)

## Deploy

Hosted on Netlify. Connect this repo and it deploys automatically on every push.

## Stack

- React 18
- Create React App
- No external dependencies beyond React
